var express=require('express');
var app= express();
var learningController=require('./controller/learningController');
var indexController=require('./controller/indexController');
var referenceController=require('./controller/referenceController');
var contentController=require('./controller/contentController');

//set template engine
app.set('view engine', 'ejs');

//fire Controller
learningController(app);
indexController(app);
contentController(app);
referenceController(app);

app.use(express.static('./public'));

//listen to port 
app.listen(4000);

