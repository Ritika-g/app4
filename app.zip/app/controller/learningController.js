var bodyParser = require("body-parser");
const fs = require("fs");
var urlencodedParser = bodyParser.urlencoded({ extended: false });

module.exports = function (app) {


  



  //get editor
  app.get('/index/learning', function (req, res) {
    res.render('learning');
  });



  app.get('/index/content/learning/show', function (req, res) {
    const fileName = `./contentFiles/fileContent.txt`;
    fs.readFile(fileName, "utf8" ,(err, data) => {
      if (err) throw err;
      console.log(data);
      res.render("show",{data});
     // res.send(data);
    });
  //  res.render('show');
    
    //readFromFile(req.body.showContent);
  });





}