var bodyParser = require("body-parser");
const fs = require("fs");
var urlencodedParser = bodyParser.urlencoded({ extended: false });


module.exports = function (app) {

  //get index
  app.get("/index/content", function (req, res) {
    res.render("content");

  });

  function WriteToFile(data,callback) {
    const fileName = `./contentFiles/fileContent.txt`;
    var text = data;
    fs.mkdir('contentFiles', function () {
      fs.appendFile(fileName, text, 'utf8', function (err, data) {

        if (err) throw err;

        console.log("Data is appended to file successfully.")
        callback(text);
      });
    });

  }



  //post data of index
  app.post("/editContent", urlencodedParser, function (req, res) {
    WriteToFile(req.body.content,function(callback){
     // console.log("hxnsjxjsjdxlkssssdhebnbdbhdjbd",callback );
    
   // res.render("show",{callback});
   res.redirect('/index/learning');
    })
  });

};