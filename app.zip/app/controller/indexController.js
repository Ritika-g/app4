var bodyParser = require("body-parser");
const fs = require("fs");
var urlencodedParser = bodyParser.urlencoded({ extended: false });

 

module.exports = function(app){
 
    //get index
    app.get("/index",function(req,res){
        res.render("index");
 
    });

    

    
 
    //post data of index
    app.post("/create-content",urlencodedParser,function(req,res){
      res.redirect("/index/learning");

    });
 
};


