var bodyParser = require("body-parser");
const fs = require("fs");
var urlencodedParser = bodyParser.urlencoded({ extended: false });
 

module.exports = function(app){
 
    //get index
    app.get("/index/reference",function(req,res){
        res.render("reference");
        
 
    });
}
